﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L14_SBLG_1129522
{
    class program
    {
        static void Main(string[] args)
        {
            int opcion = 0;


            Console.WriteLine("Bienvenido al menú, seleccione una opción:");
            Console.WriteLine("Presione 1: ------>  Edad y nombre de empleados ");
            Console.WriteLine("Presione 2: ------>  Puestos y Salarios ");
            Console.WriteLine("Presione 3: ------>  Salir");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    string[] nombres = new string[5];
                    int[] edades = new int[5];
                    int[] calculo = new int[5];


                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Ingresar el nombre de la persona");
                        nombres[i] = Console.ReadLine();
                        Console.WriteLine("Ingresar en que año nació " + nombres[i]);
                        edades[i] = int.Parse(Console.ReadLine());
                        calculo[i] = 2022 - edades[i];
                    }
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine(nombres[i] + " tiene: " + calculo[i] + " años");
                    }

                    break;

                case 2:
                    string[] puesto = new string[5];
                    double[] salario = new double[5];
                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine("Ingresar un puesto");
                        puesto[i] = Console.ReadLine();
                        Console.WriteLine("Ingresar el salario es " + puesto[i]);
                        salario[i] = double.Parse(Console.ReadLine());
                    }

                    for (int i = 0; i < 5; i++)
                    {
                        Console.WriteLine(puesto[i] + " el salario es de: " + salario[i]);
                    }
                    break;

                case 3:
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Opciones validas entre 1 y 3");
                    break;
            }

            Console.ReadKey();
        }
    }
}
